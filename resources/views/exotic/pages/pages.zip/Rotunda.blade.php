@extends('layouts.app')


@section('title', '| Capitol Rotunda')

@section('content')
    <div class="row">
        <div class="header thumbnail">
            <img src="images/WashDC/Rotunda/IMG_header.jpg">
        </div>
    </div>
    @include('partials._carousel')
    <script type="text/javascript">
        var imgfoldername = "Rotunda/";
    </script>
@stop