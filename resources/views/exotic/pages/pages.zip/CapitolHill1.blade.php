@extends('layouts.app')


@section('title', '| Capitol Hill')

@section('content')
    <div class="row">
        <div class="header thumbnail">
            <img src="images/WashDC/CapitolHill1/IMG_header.jpg">
        </div>
    </div>
    @include('partials._carousel')
    <script type="text/javascript">
        var imgfoldername = "CapitolHill1/";
    </script>
@stop