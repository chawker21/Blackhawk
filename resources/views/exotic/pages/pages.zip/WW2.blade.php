@extends('layouts.app')


@section('title', '| WW2')

@section('content')
    <div class="row">
        <div class="header thumbnail">
            <img src="images/WashDC/WW2/IMG_header.jpg">
        </div>
    </div>
    @include('partials._carousel')
    <script type="text/javascript">
        var imgfoldername = "WW2/";
    </script>
@stop