@extends('layouts.app')


@section('title', '| JFK')

@section('content')
    <div class="row">
        <div class="header thumbnail">
            <img src="images/WashDC/Tomb2/IMG_header.jpg">
        </div>
    </div>
    @include('partials._carousel')
    <script type="text/javascript">
        var imgfoldername = "Tomb2/";
    </script>
@stop