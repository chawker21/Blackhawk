@extends('layouts.app')


@section('title', '| WW1')

@section('content')
    <div class="row">
        <div class="header thumbnail">
            <img src="images/WashDC/WW1/IMG_header.jpg">
        </div>
    </div>
    @include('partials._carousel')
    <script type="text/javascript">
        var imgfoldername = "WW1/";
    </script>
@stop