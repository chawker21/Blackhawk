
<script>
var addc = document.querySelectorAll('li');
for (let i=0; i <= 4; ++i) {
    addc[i].onmouseover = function() {
        this.setAttribute("Class", 'item');

    };
    addc[i].onclick = function() {
        this.removeAttribute("class", "item");
    }
    }





</script>