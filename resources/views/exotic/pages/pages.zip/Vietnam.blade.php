@extends('layouts.app')


@section('title', '| Vietnam Memorial')

@section('content')
    <div class="row">
        <div class="header thumbnail">
            <img src="images/WashDC/Vietnam/IMG_header.jpg">
        </div>
    </div>
    @include('partials._carousel')
    <script type="text/javascript">
        var imgfoldername = "Vietnam/";
    </script>
@endsection