@extends('layouts.app')




@section('content')
    <div class="row">
        <div class="header thumbnail">
            <img src="images/WashDC/IMG_header.jpg">
        </div>
    </div>
    <div><H1 style="text-align:center;">Washington D.C.</H1></div>

<div class="main-body">
    <li class="col-xs-6 col-sm-4 col-md-3 center-block"><a href="Tomb1" >
            <img class="img-rounded img-responsive" src="images/WashDC/homepagepics/JPEG/arlington1.jpg"  alt="VM1">
            <h3 class="list-group-item-heading itemheading">Unknown Soldier</h3>
        </a>
    </li>


    <li class="col-xs-6 col-sm-4 col-md-3 center-block"><a href="Arlington1" >
            <img class="img-rounded img-responsive" src="images/WashDC/homepagepics/JPEG/arlington2.jpg" alt="VM1">
            <h3 class="list-group-item-heading itemheading">Arlington Cemetary</h3>
        </a>
    </li>
    <li class="col-xs-6 col-sm-4 col-md-3 center-block"><a href="CapitolHill1" >
            <img class="img-rounded img-responsive" src="images/WashDC/homepagepics/JPEG/capitol1.jpg" alt="VM1">
            <h3 class="list-group-item-heading itemheading">Capitol Hill 1</h3>
        </a>
    </li>
    <li class="col-xs-6 col-sm-4 col-md-3 center-block"><a href="CapitolHill2" >
            <img class="img-rounded img-responsive" src="images/WashDC/homepagepics/JPEG/capitol2.jpg" alt="VM1">
            <h3 class="list-group-item-heading itemheading">Capitol Hill 2</h3>
        </a>
    </li>
    <li class="col-xs-6 col-sm-4 col-md-3 center-block"><a href="CapitolHill3" >
            <img class="img-rounded img-responsive" src="images/WashDC/homepagepics/JPEG/capitol3.jpg"  alt="VM1">
            <h3 class="list-group-item-heading itemheading">Capitol Hill 3</h3>
        </a>
    </li>
    <li class="col-xs-6 col-sm-4 col-md-3 center-block"><a href="NatCath" >
            <img class="img-rounded img-responsive" src="images/WashDC/homepagepics/JPEG/cathedral.jpg" alt="VM1">
            <h3 class="list-group-item-heading itemheading">National Cathedral</h3>
        </a>
    </li>
    <li class="col-xs-6 col-sm-4 col-md-3 center-block"><a href="Sculptures" >
            <img class="img-rounded img-responsive" src="images/WashDC/homepagepics/JPEG/chess1.jpg" alt="VM1">
            <h3 class="list-group-item-heading itemheading">Sculptures</h3>
        </a>
    </li>
    <li class="col-xs-6 col-sm-4 col-md-3 center-block"><a href="Rotunda" >
            <img class="img-rounded img-responsive" src="images/WashDC/homepagepics/JPEG/congress.jpg" alt="VM1">
            <h3 class="list-group-item-heading itemheading">Capitol Rotunda</h3>
        </a>
    </li>
    <li class="col-xs-6 col-sm-4 col-md-3 center-block"><a href="Jefferson" >
            <img class="img-rounded img-responsive" src="images/WashDC/homepagepics/JPEG/jeffersonmemorial.jpg"  alt="VM1">
            <h3 class="list-group-item-heading itemheading">Jefferson Memorial</h3>
        </a>
    </li>
    <li class="col-xs-6 col-sm-4 col-md-3 center-block"><a href="Korea" >
            <img class="img-rounded img-responsive" src="images/WashDC/homepagepics/JPEG/koreanwarmemorial.jpg"  alt="VM1">
            <h3 class="list-group-item-heading itemheading">Korean War Memorial</h3>
        </a>
    </li>
    <li class="col-xs-6 col-sm-4 col-md-3 center-block"><a href="LOC" >
            <img class="img-rounded img-responsive" src="images/WashDC/homepagepics/JPEG/libraryofcongress.jpg"  alt="VM1">
            <h3 class="list-group-item-heading itemheading">Library of Congress</h3>
        </a>
    </li>
    <li class="col-xs-6 col-sm-4 col-md-3 center-block"><a href="lincoln" >
            <img class="img-rounded img-responsive" src="images/WashDC/homepagepics/JPEG/lincolnmemorial.jpg"  alt="VM1">
            <h3 class="list-group-item-heading itemheading">Lincoln Memorial</h3>
        </a>
    </li>
    <li class="col-xs-6 col-sm-4 col-md-3 center-block"><a href="MLK" >
            <img class="img-rounded img-responsive" src="images/WashDC/homepagepics/JPEG/mlkmemorial.jpg"  alt="VM1">
            <h3 class="list-group-item-heading itemheading">MLK Memorial</h3>
        </a>
    </li>
    <li class="col-xs-6 col-sm-4 col-md-3 center-block"><a href="Night" >
            <img class="img-rounded img-responsive" src="images/WashDC/homepagepics/JPEG/night.jpg"  alt="VM1">
            <h3 class="list-group-item-heading itemheading">Night on the Mall</h3>
        </a>
    </li>
    <li class="col-xs-6 col-sm-4 col-md-3 center-block"><a href="Pentagon" >
            <img class="img-rounded img-responsive" src="images/WashDC/homepagepics/JPEG/pentagonmemorial.jpg"  alt="VM1">
            <h3 class="list-group-item-heading itemheading">Pentagon Memorial</h3>
        </a>
    </li>
    <li class="col-xs-6 col-sm-4 col-md-3 center-block"><a href="FDR" >
            <img class="img-rounded img-responsive" src="images/WashDC/homepagepics/JPEG/rooseveltmemorial.jpg"  alt="VM1">
            <h3 class="list-group-item-heading itemheading">FDR Memorial</h3>
        </a>
    </li>
    <li class="col-xs-6 col-sm-4 col-md-3 center-block"><a href="Monuments" >
            <img class="img-rounded img-responsive" src="images/WashDC/homepagepics/JPEG/shiloh.jpg"  alt="VM1">
            <h3 class="list-group-item-heading itemheading">Monuments</h3>
        </a>
    </li>
    <li class="col-xs-6 col-sm-4 col-md-3 center-block"><a href="Tomb2" >
            <img class="img-rounded img-responsive" src="images/WashDC/homepagepics/JPEG/tombofunknownsoldier.jpg"  alt="VM1">
            <h3 class="list-group-item-heading itemheading">Unknown Soldier 2</h3>
        </a>
    </li>
    <li class="col-xs-6 col-sm-4 col-md-3 center-block"><a href="Vietnam" >
            <img class="img-rounded img-responsive" src="images/WashDC/homepagepics/JPEG/vietnammemorial.jpg"  alt="VM1">
            <h3 class="list-group-item-heading itemheading">Vietnam Memorial</h3>
        </a>
    </li>
    <li class="col-xs-6 col-sm-4 col-md-3 center-block"><a href="WashMon" >
            <img class="img-rounded img-responsive" src="images/WashDC/homepagepics/JPEG/washingtonmonument.jpg"  alt="VM1">
            <h3 class="list-group-item-heading itemheading">Washington Monument
            </h3>
        </a>
    </li>
    <li class="col-xs-6 col-sm-4 col-md-3 center-block"><a href="WhiteHouse" >
            <img class="img-rounded img-responsive" src="images/WashDC/homepagepics/JPEG/whitehouse.jpg"  alt="VM1">
            <h3 class="list-group-item-heading itemheading">White House</h3>
        </a>
    </li>
    <li class="col-xs-6 col-sm-4 col-md-3 center-block"><a href="WW1" >
            <img class="img-rounded img-responsive" src="images/WashDC/homepagepics/JPEG/ww1.jpg"  alt="VM1">
            <h3 class="list-group-item-heading itemheading">WW1 Monument</h3>
        </a>
    </li>
    <li class="col-xs-6 col-sm-4 col-md-3 center-block"><a href="WW2" >
            <img class="img-rounded img-responsive" src="images/WashDC/homepagepics/JPEG/ww2memorial.jpg"  alt="VM1">
            <h3 class="list-group-item-heading itemheading">World War 2 Memorial</h3>
        </a>
    </li>
    <li class="col-xs-6 col-sm-4 col-md-3 center-block"><a href="Lafayette" >
            <img class="img-rounded img-responsive" src="images/WashDC/homepagepics/JPEG/jackson.jpg" alt="VM1">
            <h3 class="list-group-item-heading itemheading">Lafayette Square</h3>
        </a>
    </li>
</div>
    @endsection
