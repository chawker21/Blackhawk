@extends('layouts.app')


@section('title', '| Capitol Rotunda')

@section('content')
    <div class="row">
        <div class="header thumbnail">
            <img src="images/WashDC/Pentagon/IMG_header.jpg">
        </div>
    </div>
    @include('partials._carousel')
    <script type="text/javascript">
        var imgfoldername = "Pentagon/";
    </script>
@stop