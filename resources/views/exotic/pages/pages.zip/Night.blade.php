@extends('layouts.app')


@section('title', '| Night')

@section('content')
    <div class="row">
        <div class="header thumbnail">
            <img src="images/WashDC/Night/IMG_header.jpg">
        </div>
    </div>
    @include('partials._carousel')
    <script type="text/javascript">
        var imgfoldername = "Night/";
    </script>
@stop