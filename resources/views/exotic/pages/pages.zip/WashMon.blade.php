@extends('layouts.app')


@section('title', '| WashMon')

@section('content')
    <div class="row">
        <div class="header thumbnail">
            <img src="images/WashDC/WashMon/IMG_header.jpg">
        </div>
    </div>
    @include('partials._carousel')
    <script type="text/javascript">
        var imgfoldername = "WashMon/";
    </script>
@stop