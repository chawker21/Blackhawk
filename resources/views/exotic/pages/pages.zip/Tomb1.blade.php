@extends('layouts.app')


@section('title', '| Tomb of the Unknown Soldier')

@section('content')
    <div class="row">
        <div class="header thumbnail">
            <img src="images/WashDC/Tomb1/IMG_header.jpg">
        </div>
    </div>
    @include('partials._carousel')
    <script type="text/javascript">
        var imgfoldername = "Tomb1/";
    </script>
@stop