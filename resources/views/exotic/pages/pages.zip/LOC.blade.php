@extends('layouts.app')


@section('title', '| Library of Congress')

@section('content')
    <div class="row">
        <div class="header thumbnail">
            <img src="images/WashDC/LOC/IMG_header.jpg">
        </div>
    </div>
    @include('partials._carousel')
    <script type="text/javascript">
        var imgfoldername = "LOC/";
    </script>
@stop