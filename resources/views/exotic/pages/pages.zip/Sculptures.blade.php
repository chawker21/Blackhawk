@extends('layouts.app')


@section('title', '| Sculptures')

@section('content')
    <div class="row">
        <div class="header thumbnail">
            <img src="images/WashDC/Sculptures/IMG_header.jpg">
        </div>
    </div>
    @include('partials._carousel')
    <script type="text/javascript">
        var imgfoldername = "Sculptures/";
    </script>
@stop